package com.ejemplo.tarea;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText edit1;
    private EditText edit2;
    private TextView tv1;
    // adicionamos
    private CheckBox rb1, rb2, rb3, rb4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit1 = (EditText) findViewById(R.id.txt_num1);
        edit2 = (EditText) findViewById(R.id.txt_num2);
        tv1 = (TextView) findViewById(R.id.txt_view1);
        rb1 = (CheckBox) findViewById(R.id.btn_suma);
        rb2 = (CheckBox) findViewById(R.id.btn_resta);
        rb3 = (CheckBox) findViewById(R.id.btn_multiplicar);
        rb4 = (CheckBox) findViewById(R.id.btn_dividir);

    }

    /*Metodo para calcular*/

    public void Calcular(View view) {

        String valor1 = edit1.getText().toString();
        String valor2 = edit2.getText().toString();

        int num1 = Integer.parseInt(valor1);
        int num2 = Integer.parseInt(valor2);

        if (rb1.isChecked() == true && rb2.isChecked() == true && rb3.isChecked() == true && rb4.isChecked() == true) {
            if (num1 >= num2) {
                int suma = num1 + num2;
                int resta = num1 - num2;
                int multiplicar = num1 * num2;
                int dividir = num1 / num2;
                String resulSuma = String.valueOf(suma);
                String resulResta = String.valueOf(resta);
                String resulMulti = String.valueOf(multiplicar);
                String resulDividir = String.valueOf(dividir);
                tv1.setText("la suma es : " + resulSuma + "\n la resta es: " + resulResta + "\n la multiplicacion es : " + resulMulti + " \n la division es: " + resulDividir);
            }else {
                int suma = num1 + num2;
                int multiplicar = num1 * num2;
                String resulSuma = String.valueOf(suma);
                String resulMulti = String.valueOf(multiplicar);
                tv1.setText("no se puede restar ni dividir \n la suma es : " + resulSuma + "\n la multiplicacion es : " + resulMulti);
     }
        }else if (rb1.isChecked() == true && rb2.isChecked() == true && rb3.isChecked() == true) {
        if(num1 >= num2) {
            int suma = num1 + num2;
            int resta = num1 - num2;
            int multiplicar = num1 * num2;
            String resulSuma = String.valueOf(suma);
            String resulResta = String.valueOf(resta);
            String resulMulti = String.valueOf(multiplicar);
            tv1.setText("la suma es : " + resulSuma + "\n la resta es: " + resulResta + "\n la multiplicacion es : " + resulMulti);
        }else{
            int suma = num1 + num2;
            int multiplicar = num1 * num2;
            String resulSuma = String.valueOf(suma);
            String resulMulti = String.valueOf(multiplicar);
            tv1.setText("la suma es : " + resulSuma + "\n no se puede restar \n la multiplicacion es : " + resulMulti);
        }













        }else if (rb1.isChecked() == true && rb2.isChecked() == true) {
            if (num1 >= num2) {
                int suma = num1 + num2;
                int resta = num1 - num2;
                String resulSuma = String.valueOf(suma);
                String resulResta = String.valueOf(resta);
                tv1.setText("la suma es : " + resulSuma + "\n la resta es: " + resulResta);
            }else{
                int suma = num1 + num2;
                String resulSuma = String.valueOf(suma);
                tv1.setText("la suma es : " + resulSuma + "\n no se puede restar");
            }}
        else if (rb1.isChecked() == true && rb4.isChecked() == true) {
            if (num1 >= num2) {
                int suma = num1 + num2;
                int div = num1 / num2;
                String resulSuma = String.valueOf(suma);
                String resulDiv = String.valueOf(div);
                tv1.setText("la suma es : " + resulSuma + "\n la division es: " + div);
            }else{
                int suma = num1 + num2;
                String resulSuma = String.valueOf(suma);
                tv1.setText("la suma es : " + resulSuma + "\n no se puede dividir");
            }}

            else if (rb1.isChecked() == true && rb3.isChecked() == true) {

                    int suma = num1 + num2;
                    int mult = num1 * num2;
                    String resulSuma = String.valueOf(suma);
                    String resulMult = String.valueOf(mult);
                    tv1.setText("la suma es : " + resulSuma + "\n la multiplicacion es: " + resulMult);
                }

            else if (rb4.isChecked() == true && rb3.isChecked() == true) {
            if (num1 >= num2) {
                int mul = num1 * num2;
                int div = num1 / num2;
                String resulMul = String.valueOf(mul);
                String resulDiv = String.valueOf(div);
                tv1.setText("la multiplicacion es : " + resulMul + "\n la division es: " + resulDiv);
            } else {
                int mul = num1 * num2;
                String resulMul = String.valueOf(mul);
                tv1.setText("la multiplicacion es : " + resulMul + "\n no se puede dividir");

            }

        }
            else if (rb2.isChecked() == true && rb3.isChecked() == true) {
                if(num1 >= num2) {
                    int mul = num1 * num2;
                    int res = num1 / num2;
                    String resulMul = String.valueOf(mul);
                    String resulRes = String.valueOf(res);
                    tv1.setText( "la resta es: " + resulRes+"\n la multiplicacion es : " + resulMul);
                }else{
                    int mul = num1 * num2;
                    String resulMul = String.valueOf(mul);
                    tv1.setText("la multiplicacion es : " + resulMul + "\n no se puede restar");

                }}

            else if (rb2.isChecked() == true && rb4.isChecked() == true) {
                if(num1 >= num2) {
                    int div = num1 - num2;
                    int res = num1 / num2;
                    String resulDiv = String.valueOf(div);
                    String resulRes = String.valueOf(res);
                    tv1.setText( "la resta es: " + resulRes+"\n la division es : " +resulDiv);
                }else{
                    int mul = num1 * num2;
                    String resulMul = String.valueOf(mul);
                    tv1.setText(" no se puede restar ni dividir");

                }
            }else if (rb2.isChecked() == true && rb4.isChecked() == true && rb3.isChecked() == true) {
                int mul;
                if(num1 >= num2) {
                int resta = num1 - num2;
                 mul = num1 * num2;
                int div = num1 / num2;
                String resulResta = String.valueOf(resta);
                String resulMul = String.valueOf(mul);
                String resulDiv = String.valueOf(div);
                tv1.setText("La resta es : " + resulResta + " \n la multiplicacion es : " + resulMul + "\n la division es: " + resulDiv);
            }else{
            mul = num1 * num2;
            String resulMul = String.valueOf(mul);
            tv1.setText("la multiplicacion es : " + resulMul + "\n no se puede restar y dividir");
        }}










        else if (rb1.isChecked() == true && rb4.isChecked() == true && rb3.isChecked() == true) {

            if(num1 >= num2) {
                int suma = num1 + num2;
               int  mul = num1 * num2;
                int div = num1 / num2;
                String resulResta = String.valueOf(suma);
                String resulMul = String.valueOf(mul);
                String resulDiv = String.valueOf(div);
                tv1.setText("La suma es : " + resulResta + " \n la multiplicacion es : " + resulMul + "\n la division es: " + resulDiv);
            }else{
                int mul = num1 * num2;
                int suma = num1 + num2;
                String resulMul = String.valueOf(mul);
                String resulSuma = String.valueOf(suma);
                tv1.setText("la suma es : "+resulSuma+"la multiplicacion es : " + resulMul + "\n no se puede dividir");
            }}
        else if (rb1.isChecked() == true && rb4.isChecked() == true && rb2.isChecked() == true) {

            if(num1 >= num2) {
                int suma = num1 + num2;
                int res = num1 - num2;
                int div = num1 / num2;
                String resulResta = String.valueOf(suma);
                String resulMul = String.valueOf(res);
                String resulDiv = String.valueOf(div);
                tv1.setText("La suma es : " + resulResta + " \n la resta es : " + resulMul + "\n la division es: " + resulDiv);
            }else{
               int res = num1 * num2;
                int suma = num1 + num2;
                String resulMul = String.valueOf(res);
                String resulSuma = String.valueOf(suma);
                tv1.setText("la suma es : "+resulSuma+"la resta : " + resulMul + "\n no se puede dividir");
            }}
            else if (rb1.isChecked() == true) {
            int suma = num1 + num2;
            String resulSuma = String.valueOf(suma);
            tv1.setText("la suma es : " + resulSuma);
        } else if (rb2.isChecked() == true) {
         if(num1 >= num2 ){
             int resta = num1 - num2;
             String resulResta = String.valueOf(resta);
             tv1.setText("la resta es :" + resulResta);
         }else
             tv1.setText("no se puede restar");

        } else if (rb3.isChecked() == true) {
                int multi = num1 * num2;
                String resulMulti = String.valueOf(multi);
                tv1.setText("la multiplicacion es : " + resulMulti);
            } else if (rb4.isChecked() == true) {
                 if(num1 >= num2) {
                     int divi = num1 / num2;
                     String resulDiv = String.valueOf(divi);
                     tv1.setText("la division es : "+resulDiv);
                 }else
                     tv1.setText("no se puede dividir");
        }
            }
        }